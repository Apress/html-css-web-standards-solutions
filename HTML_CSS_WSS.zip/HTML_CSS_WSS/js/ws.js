// This simple JavaScript function loads a random message
// into the element with an id of 'message'.
// Nicklas Persson + Christopher Murphy, 1229452780. Tom Fun.
window.onload = function()
{
var messages=new Array(
// These are our messages to you...
"Hey, hey, we're the Monkees!",
"Wax on ... wax off. Don't forget to breathe. Very important!",
"A closed tag is a valid tag.",
"One banana, two banana, three banana, four...",
"First pants, THEN your shoes.",
"To iterate is human, to recurse divine.",
"You know the saying, 'Human see, human do.'",
"We must develop knowledge optimization initiatives to leverage our key learnings.",
"Validate! Validate! Validate!",
"You're the star of this picture. Get into character and head towards the animals.",
"Then I figured that something was rotten in Denver.",
"Computers are useless. They can only give you answers."
);
var random=Math.floor(Math.random()*messages.length)
var message = messages[random];
document.getElementById('message').innerHTML = message;
}