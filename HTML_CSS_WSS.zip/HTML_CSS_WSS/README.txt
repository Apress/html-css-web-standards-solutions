These web pages contain all the files you'll need to complete the homework for the book in addition to reference files and links to resources related to each of the chapters.

Start by opening the top level 'index.html' file in your browser, it links to a separate page for each of the chapters in the book.

You can find the latest versions of these files, including additional code examples, walkthroughs and resources at the book's companion web site:

http://www.webstandardistas.com/